<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome_model extends CI_model
{
	
	public function login_submit($username,$password)
	{
		$this->db->select('id,username');
		$this->db->from('register');
		$this->db->where('username', $username); 
		$this->db->where('password', md5($password));
		$query = $this->db->get();
		$result= $query->result();
		return $result;
	}
	

	public function get_user_details($user_id)
	{
		$this->db->select('*');
		$this->db->from('register');
		$this->db->where('id', $user_id); 
		$query = $this->db->get();
		$result= $query->result();
		return $result;
	}
	

	public function register_submit($username,$name,$contact,$email,$gender,$skills,$description,$image,$password)
	{
		$data = array(
				'username'=>$username,
				'password'=>md5($password),
				'name'=>$name,
				'contact'=>$contact,
				'email'=>$email,
				'gender'=>$gender,
				'skills'=>$skills,
				'description'=>$description,
				'image'=>$image
			);
		$this->db->insert('register',$data);
	}
	

	public function update_profile($username,$name,$contact,$email,$gender,$skills,$description,$image,$user_id)
	{
		if($image !=""){
			$data = array(
				'username'=>$username,
				'name'=>$name,
				'contact'=>$contact,
				'email'=>$email,
				'gender'=>$gender,
				'skills'=>$skills,
				'description'=>$description,
				'image'=>$image
			);
		}
		else{
			$data = array(
				'username'=>$username,
				'name'=>$name,
				'contact'=>$contact,
				'email'=>$email,
				'gender'=>$gender,
				'skills'=>$skills,
				'description'=>$description
			);
		}
		$this->db->where('id',$user_id);
		$this->db->update('register',$data);
	}
	

	public function get_products()
	{
		$this->db->select('*');
		$this->db->from('product');
		$query = $this->db->get();
		$result= $query->result();
		return $result;
	}
	

	public function add_product_submit($name,$description,$image)
	{
		$data = array(
				'name'=>$name,
				'description'=>$description,
				'image'=>$image
			);
		$this->db->insert('product',$data);
	}
	

	public function get_product_details($id)
	{
		$this->db->select('*');
		$this->db->from('product');
		$this->db->where('id', $id);
		$query = $this->db->get();
		$result= $query->result();
		return $result;
	}
	

	public function edit_product_submit($name,$description,$image,$id)
	{
		if($image !=""){
			$data = array(
				'name'=>$name,
				'description'=>$description,
				'image'=>$image
			);
		}
		else{
			$data = array(
				'name'=>$name,
				'description'=>$description
			);
		}
		$this->db->where('id',$id);
		$this->db->update('product',$data);
	}
	

	public function delete_product($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('product');
	}
	
	
}
?>
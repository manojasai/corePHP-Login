<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->library(array('session'));
		$this->load->helper(array('url','form','date'));
		$this->load->database();
		$this->load->model ('welcome_model');
	}
	
	public function index()
	{
		$this->load->view('login');
	}
	
	
	public function login_submit()
	{
		$username=$this->input->post('username');	
		$password=$this->input->post('password');
		$result=$this->welcome_model->login_submit($username,$password);
		
		if(count($result)>0)
		{
			$session_data=array(
				'user_id' =>$result[0]->id,
				'username' =>$result[0]->username,
				'logged_in' => TRUE
			);
			$this->session->set_userdata($session_data);
			redirect('welcome/dashboard');
		}else{
			$data['message'] ="<span style='color:red;'>Invalid Username or Password</span>";
			$this->load->view('login',$data);
		}
	}
	
	public function dashboard()
	{
		$user_id = $this->session->userdata('user_id');
		if($user_id !=""){
			$data['user'] =$this->welcome_model->get_user_details($user_id);
			$this->load->view('dashboard', $data);
		}
		else{
			redirect('welcome/index');
		}
	}
	
	public function register_submit()
	{
		$username=$this->input->post('username');	
		$password=$this->input->post('password');	
		$name=$this->input->post('name');
		$contact=$this->input->post('contact');
		$email=$this->input->post('email');
		$gender=$this->input->post('gender');
		$skills=$this->input->post('skills');
		$description=$this->input->post('description');
		$image ="";
		if($_FILES['image']['name'] !=""){
			$path = $_FILES['image']['name'];
			$ext = pathinfo($path, PATHINFO_EXTENSION);
			$file_name = time().'.'.$ext;
			$config['upload_path']   = './uploads/'; 
			$config['allowed_types'] = 'gif|jpg|png'; 
			$config['file_name'] = $file_name;
			
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload('image')) {
				$image = $file_name;
			 }
		}
		//echo $image; exit;
		$result=$this->welcome_model->register_submit($username,$name,$contact,$email,$gender,$skills,$description,$image,$password);
		$data['message'] ="<span style='color:green;'>Register successfully</span>";
		$this->load->view('login',$data);
	}
	
	public function profile_update()
	{
		$username=$this->input->post('username');	
		$name=$this->input->post('name');
		$contact=$this->input->post('contact');
		$email=$this->input->post('email');
		$gender=$this->input->post('gender');
		$skills=$this->input->post('skills');
		$description=$this->input->post('description');
		$user_id = $this->session->userdata('user_id');
		$image ="";
			if($_FILES['image']['name'] !=""){
				$path = $_FILES['image']['name'];
				$ext = pathinfo($path, PATHINFO_EXTENSION);
				$file_name = time().'.'.$ext;
				$config['upload_path']   = './uploads/'; 
				$config['allowed_types'] = 'gif|jpg|png'; 
				$config['file_name'] = $file_name;
				
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				if ($this->upload->do_upload('image')) {
					$image = $file_name;
				 }
			}
		//echo $image; exit;
		$result=$this->welcome_model->update_profile($username,$name,$contact,$email,$gender,$skills,$description,$image,$user_id);
		
		redirect('welcome/dashboard');
	}
	
	
	public function logout()
	{
		$this->session->sess_destroy();
		
		redirect('welcome/index');
	}
	
	
	public function manage_product()
	{
		$data['product'] =$this->welcome_model->get_products();
		$this->load->view('manage_product', $data);
		
	}
	
	public function add_product()
	{
		$this->load->view('add_product');
	}
	
	
	public function add_product_submit()
	{
		$name=$this->input->post('name');
		$description=$this->input->post('description');
		$image ="";
		if($_FILES['image']['name'] !=""){
			$path = $_FILES['image']['name'];
			$ext = pathinfo($path, PATHINFO_EXTENSION);
			$file_name = time().'.'.$ext;
			$config['upload_path']   = './uploads/'; 
			$config['allowed_types'] = 'gif|jpg|png'; 
			$config['file_name'] = $file_name;
			
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			if ($this->upload->do_upload('image')) {
				$image = $file_name;
			 }
		}
		//echo $image; exit;
		$result=$this->welcome_model->add_product_submit($name,$description,$image);
		redirect('welcome/manage_product');
	}
	
	public function edit_product($id)
	{
		$data['product'] =$this->welcome_model->get_product_details($id);
		$this->load->view('edit_product', $data);
	}
	
	public function edit_product_submit()
	{	
		$name=$this->input->post('name');
		$description=$this->input->post('description');
		$id=$this->input->post('id');
		$image ="";
			if($_FILES['image']['name'] !=""){
				$path = $_FILES['image']['name'];
				$ext = pathinfo($path, PATHINFO_EXTENSION);
				$file_name = time().'.'.$ext;
				$config['upload_path']   = './uploads/'; 
				$config['allowed_types'] = 'gif|jpg|png'; 
				$config['file_name'] = $file_name;
				
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				if ($this->upload->do_upload('image')) {
					$image = $file_name;
				 }
			}
		//echo $image; exit;
		$result=$this->welcome_model->edit_product_submit($name,$description,$image,$id);
		
		redirect('welcome/manage_product');
	}
	
	public function delete_product($id)
	{	
		$result=$this->welcome_model->delete_product($id);
		
		redirect('welcome/manage_product');
	}
	
}

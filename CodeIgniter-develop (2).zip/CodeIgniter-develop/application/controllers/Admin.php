<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->library(array('session'));
		$this->load->helper(array('url','form','date'));
		
		$this->load->model ('admin_model');
	}
	
	public function index()
	{
		$this->load->view('login');
	}
}
